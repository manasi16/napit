package com.example.android.fitnessapp2;
// written by Aishwarya Srikanth
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
// A screen to show answers to some frequently asked questions
public class FAQ extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
    }
}
