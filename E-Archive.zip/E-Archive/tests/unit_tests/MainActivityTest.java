package com.example.android.fitnessapp2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by john on 12/12/17.
 */
public class MainActivityTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void onCreate() throws Exception {
    }

    @Test
    public void SQLiteDataBaseBuild() throws Exception {
    }

    @Test
    public void SQLiteTableBuild() throws Exception {
        // don't run this automatically. test by hand!
    }

    @Test
    public void loginFunction() throws Exception {

    }

    @Test
    public void onClick() throws Exception {
    }

}