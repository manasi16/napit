package com.example.android.fitnessapp2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by john on 12/12/17.
 */
public class ShowMoreTest {
    @Before
    public void setUp() throws Exception {
    }   // does nothing

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void onCreate() throws Exception {
    }

}